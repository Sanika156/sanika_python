a=int(input("enter a no: "))
b=int(input("enter a no: "))
c=int(input("enter a no: "))
if(a>b and a>c):
    print(a,"is greater")
elif(b>a and b>c):
    print(b,"is greater")
else:
    print(c,"is greater")
