b='*\n**\n***\n****\n*****'
print(b)
