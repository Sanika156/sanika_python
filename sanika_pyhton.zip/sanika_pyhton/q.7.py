
a=int(input("enter a no: "))
b=1
while a>=1:
    b=b*a
    a=a-1
print(b)



