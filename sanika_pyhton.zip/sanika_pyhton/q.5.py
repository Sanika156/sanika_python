a=int(input("enter a no: "))
b=int(input("enter a no: "))
temp=a
a=b
b=temp
print("after swapping: a=",a,"after swapping: b=",b)
