n=int(input("enter a no: "))
b=n
rev=0
while(n>0):
    x=n%10
    rev=rev*10+x
    n=n//10
if(b==rev):
    print("no is a palindrome")
else:
    print("no is not a palindrome")

