a='Name:Utkarsh\t\t\t\tDesignation:Faculty\nID:321ABZ\t\t\t\tPassword:zzz@123\nEmail:abc1234@gmail.com'
print(a)
