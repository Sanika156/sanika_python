
a=int(input("enter a no: "))
b=0
while(a>0):
    d=a%10
    b=b+d
    a=a//10
print("the total sum of digits is: ",b)

