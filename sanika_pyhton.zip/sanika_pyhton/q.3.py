a=int(input("enter a no: "))
if(a==0):
    print(a,"is zero")
elif(a%2==0):
    print(a,"is even")
else:
    print(a,"is odd")
